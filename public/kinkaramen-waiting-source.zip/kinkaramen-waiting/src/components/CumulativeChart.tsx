import { MODEL } from '../models/modelConstants';
import { CartesianGrid, Line, LineChart, ReferenceArea, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { clock } from '../utils/time';
import { percent } from '../utils/probability';
import type { PositionResult } from '../models/simulation';
export function CumulativeChart({current,selected,target,tolerance}:{current:PositionResult;selected:PositionResult;target:number;tolerance:number}) {
  const data=[{time:current.bins[0].time,current:0,selected:0},...current.bins.map((b,i)=>({time:b.time+5,current:b.cumulative,selected:selected.bins[i]?.cumulative??0}))];
  const last = Math.max(current.bins.find(b=>b.cumulative>=.995)?.time??current.bins.at(-1)!.time, selected.bins.find(b=>b.cumulative>=.995)?.time??selected.bins.at(-1)!.time, target+tolerance)+5;
  const visible = data.filter(d=>d.time<=last);
  const distinct=current.rank!==selected.rank;
  return <div className="chart-shell" role="img" aria-label="누적 호출확률. 각 시간까지 호출된 전체 시나리오의 비율이에요."><ResponsiveContainer width="100%" height="100%"><LineChart data={visible} margin={{top:24,right:12,left:-22,bottom:2}}><CartesianGrid vertical={false} stroke="#edf0f4"/><XAxis type="number" dataKey="time" domain={['dataMin',Math.min(data.at(-1)!.time,last)]} tickFormatter={clock} tick={{fontSize:11,fill:'#8b95a1'}} axisLine={false} tickLine={false} minTickGap={25}/><YAxis domain={[0,1]} ticks={[0,.25,.5,.75,1]} tickFormatter={v=>`${Math.round(v*100)}%`} tick={{fontSize:11,fill:'#8b95a1'}} axisLine={false} tickLine={false}/><ReferenceArea x1={target-MODEL.graceMinutes} x2={target+tolerance} fill="#3182f6" fillOpacity={.055}/><ReferenceLine x={target} stroke="#3182f6" strokeDasharray="4 4" label={{value:'도착',position:'top',fontSize:11,fill:'#3182f6'}}/><Tooltip contentStyle={{border:0,borderRadius:12,fontSize:12,boxShadow:'0 8px 30px #172b4d18'}} labelFormatter={v=>`${clock(Number(v))}까지`} formatter={(v,name)=>[percent(Number(v)),name]}/><Line type="stepAfter" name={`현재 ${current.rank}번째`} dataKey="current" stroke={distinct?'#a9b7c9':'#3182f6'} strokeWidth={2.5} dot={false} isAnimationActive={false}/>{distinct&&<Line type="stepAfter" name={`선택 ${selected.rank}번째`} dataKey="selected" stroke="#3182f6" strokeWidth={3} dot={false} isAnimationActive={false}/>}</LineChart></ResponsiveContainer></div>;
}
